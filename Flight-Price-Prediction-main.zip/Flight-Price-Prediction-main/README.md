# Flight-Price-Prediction
Link to the heroku app: https://flight-price-s.herokuapp.com/
